import SwiftUI

struct ContentView: View {
    @State private var id = 0
    let maxID = 15   
    private var bits: [String] {
        Array(decimalToBinary(id)).map { String($0) }
    }
    
    func decimalToBinary(_ number: Int) -> String {
        let powers = [8, 4, 2, 1]
        var n = number % 16
        var s = ""
        for p in powers {
            if n >= p {
                s += "1"
                n -= p
            } else {
                s += "0"
            }
        }
        return s
    }
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea() // siyah arka plan
            
            VStack(spacing: 24) {
                Text("Binary Counter")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.blue)
                
                VStack(spacing: 4) {
                    Text("Decimal: \(id)")
                        .foregroundColor(.white)
                    Text("Binary: \(decimalToBinary(id))")
                        .font(.system(.body, design: .monospaced))
                        .foregroundColor(.blue)
                }
                
                HStack(spacing: 14) {
                    ForEach(0..<4, id: \.self) { i in
                        RoundedRectangle(cornerRadius: 8)
                            .fill(bits[i] == "1" ? Color.blue : Color.gray.opacity(0.2))
                            .frame(width: 60, height: 60)
                            .overlay(
                                Text(bits[i])
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(.white)
                            )
                            .shadow(color: bits[i] == "1" ? .blue.opacity(0.6) : .clear, radius: 6)
                    }
                }
                
                HStack(spacing: 20) {
                    Button("-1") {
                        if id == 0 { id = maxID } else { id -= 1 }
                    }
                    .buttonStyle(BlueButton())
                    
                    Button("+1") {
                        if id == maxID { id = 0 } else { id += 1 }
                    }
                    .buttonStyle(BlueButton())
                    
                    Button("Reset") {
                        id = 0
                    }
                    .buttonStyle(BlueButton())
                }
            }
            .padding()
        }
    }
}

struct BlueButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .frame(width: 70, height: 40)
            .background(Color.blue.opacity(configuration.isPressed ? 0.5 : 0.8))
            .foregroundColor(.white)
            .cornerRadius(8)
            .animation(.easeInOut(duration: 0.2), value: configuration.isPressed)
    }
}


