import SwiftUI

struct ContentView: View {
    @State private var level = 1
    @State private var passCount = 0
    @State private var timeLeft = 20
    @State private var isRunning = false
    
    @State private var playerX: CGFloat = 0
    
    @State private var gameWidth: CGFloat = 300
    
    let obstacles: [CGRect] = [
        CGRect(x: 180, y: 120, width: 50, height: 40),
        CGRect(x: 80, y: 180, width: 60, height: 40),
        CGRect(x: 200, y: 240, width: 60, height: 40)
    ]
    
    func initialTimeForLevel(_ level: Int) -> Int {
        if level == 1 {
            return 20
        } else if level == 2 {
            return 18
        } else if level == 3 {
            return 16
        } else if level == 4 {
            return 14
        } else {
            return 8
        }
    }
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack(spacing: 16) {
                
                Text("\(timeLeft)s")
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding(8)
                    .background(Circle().stroke(Color.white, lineWidth: 3))
                
                Text("Level \(level) • Pass \(passCount)/3")
                    .foregroundColor(.white)
                    .font(.headline)
                
                ZStack(alignment: .top) {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.black.opacity(0.4))
                        .frame(height: 300)
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.gray, lineWidth: 2)
                        )
                        .background(
                            GeometryReader { geo in
                                Color.clear.onAppear {
                                    gameWidth = geo.size.width
                                }
                            }
                        )
                    
                    Rectangle()
                        .fill(Color.green)
                        .frame(height: 40)
                        .cornerRadius(10)
                        .padding(.horizontal, 8)
                    
                    ForEach(0..<obstacles.count, id: \.self) { i in
                        let obs = obstacles[i]
                        Rectangle()
                            .fill(i == 0 ? Color.orange : (i == 1 ? Color.purple : Color.red))
                            .frame(width: obs.width, height: obs.height)
                            .position(x: obs.midX, y: obs.midY)
                    }
                    
                    Circle()
                        .fill(Color.blue)
                        .frame(width: 30, height: 30)
                        .position(
                            x: gameWidth / 2 + playerX,
                            y: 280
                        )
                }
                .frame(height: 300)
                
                HStack(spacing: 20) {
                    Button {
                        movePlayer(by: -20)
                    } label: {
                        Image(systemName: "arrow.left")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.orange)
                            .cornerRadius(12)
                    }
                    
                    Button {
                        movePlayer(by: 20)
                    } label: {
                        Image(systemName: "arrow.right")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.orange)
                            .cornerRadius(12)
                    }
                }
                
                Button {
                    startGame()
                } label: {
                    Text("Start / Restart")
                        .font(.headline)
                        .padding(.horizontal, 40)
                        .padding(.vertical, 12)
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                }
                
                Spacer()
            }
            .padding()
        }
        .onReceive(timer) { _ in
            guard isRunning else { return }
            if timeLeft > 0 {
                timeLeft -= 1
            } else {
                print("TIME UP! Restarting clock…")
                resetGame()
            }
        }
    }
    
    func movePlayer(by amount: CGFloat) {
        guard isRunning else { return }
        playerX += amount
        
        let maxOffset = gameWidth / 2 - 20
        if playerX > maxOffset { playerX = maxOffset }
        if playerX < -maxOffset { playerX = -maxOffset }
        
        checkCollision()
        

    }
    
    func checkCollision() {
        let playerRect = CGRect(
            x: (gameWidth / 2 + playerX) - 15,
            y: 280 - 15,
            width: 30,
            height: 30
        )
        
        for obs in obstacles {
            if playerRect.intersects(obs) {
                print("HIT OBSTACLE! Resetting level…")
                resetGame()
                return
            }
        }
    }
    
    func startGame() {
        isRunning = true
        timeLeft = initialTimeForLevel(level)
        playerX = 0
    }
    

    func resetGame() {
        isRunning = false
        timeLeft = initialTimeForLevel(level)
        playerX = 0
    }
    
 
    func nextLevel() {
        level += 1
        timeLeft = initialTimeForLevel(level)
        playerX = 0
    }
}
