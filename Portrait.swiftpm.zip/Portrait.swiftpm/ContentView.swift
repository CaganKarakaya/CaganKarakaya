import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            
            Circle()
                .frame(width: 300, height: 300)
                .foregroundColor(.yellow)
                .opacity(0.8)
                .shadow(radius: 5)
            
            HStack(spacing: 100) {
                Circle()
                    .frame(width: 40, height: 40)
                    .foregroundColor(.black)
                Circle()
                    .frame(width: 40, height: 40)
                    .foregroundColor(.black)
            }
            .offset(y: -40)
            
            Capsule()
                .frame(width: 120, height: 20)
                .foregroundColor(.red)
                .offset(y: 60)
            
            
            Triangle()
                .fill(Color.orange)
                .frame(width: 30, height: 40)
                .offset(y: 10)
            
            Rectangle()
                .frame(width: 200, height: 50)
                .foregroundColor(.blue)
                .offset(y: -170)
            Rectangle()
                .frame(width: 120, height: 60)
                .foregroundColor(.blue)
                .offset(y: -200)
        }
    }
}

struct Triangle: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.midX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
        path.closeSubpath()
        return path
    }
}
