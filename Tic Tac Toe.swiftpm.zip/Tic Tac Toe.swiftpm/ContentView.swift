import SwiftUI

struct ContentView: View {
    @State private var board: [String] = Array(repeating: "", count: 9)
    @State private var player: String = "X"
    @State private var winner: String? = nil      
    @State private var isDraw: Bool = false         
    @State private var gameOver: Bool = false        
    
    let cellSize: CGFloat = 100
    
    var body: some View {
        VStack(spacing: 16) {
            Text(statusText)
                .font(.title2)
                .bold()
                .padding(.top, 8)
            
            
            VStack(spacing: 12) {
                ForEach(0..<3, id: \.self) { row in
                    HStack(spacing: 12) {
                        ForEach(0..<3, id: \.self) { col in
                            let index = row * 3 + col
                            ZStack {
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(.blue)
                                    .frame(width: cellSize, height: cellSize)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 16)
                                            .stroke(.white.opacity(0.3), lineWidth: 1)
                                    )
                                    .onTapGesture { handleTap(at: index) }
                                    .opacity(canTap(at: index) ? 1 : 0.6)
                                
                                Text(board[index])
                                    .font(.system(size: 40, weight: .heavy, design: .rounded))
                                    .foregroundColor(.white)
                            }
                        }
                    }
                }
            }
            .padding(.vertical, 8)
            
            HStack(spacing: 12) {
                Button("Yeniden Başlat") { resetGame() }
                    .buttonStyle(.borderedProminent)
                
                Button("Sırayı Değiştir (X/O)") {
                    guard !gameOver else { return }
                    player = (player == "X") ? "O" : "X"
                }
                .buttonStyle(.bordered)
            }
        }
        .padding()
        .animation(.easeInOut, value: board)
    }
    
    
    private var statusText: String {
        if let w = winner {
            let loser = (w == "X") ? "O" : "X"
            return "Kazanan: \(w) • Kaybeden: \(loser)"
        } else if isDraw {
            return "Berabere!"
        } else {
            return "Sıra: \(player)"
        }
    }
    
    
    private func canTap(at index: Int) -> Bool {
        return !gameOver && board[index].isEmpty
    }
    
    
    private func handleTap(at index: Int) {
        guard canTap(at: index) else { return }
        board[index] = player
        checkGameState()
        if !gameOver { togglePlayer() }
    }
    
    private func togglePlayer() {
        player = (player == "X") ? "O" : "X"
    }
    
   
    private func checkGameState() {
        let lines: [[Int]] = [
            [0,1,2],[3,4,5],[6,7,8],
            [0,3,6],[1,4,7],[2,5,8], 
            [0,4,8],[2,4,6]          
        ]
        
        for line in lines {
            let a = line[0], b = line[1], c = line[2]
            if !board[a].isEmpty, board[a] == board[b], board[b] == board[c] {
                winner = board[a]
                gameOver = true
                isDraw = false
                return
            }
        }
        
        
        if !board.contains("") {
            isDraw = true
            gameOver = true
            winner = nil
        }
    }
    
    private func resetGame() {
        board = Array(repeating: "", count: 9)
        player = "X"
        winner = nil
        isDraw = false
        gameOver = false
    }
}
