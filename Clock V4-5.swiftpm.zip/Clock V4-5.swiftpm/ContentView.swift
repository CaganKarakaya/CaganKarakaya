import SwiftUI

struct ContentView: View {
    @State var hour = 0
    @State var minute = 0
    
    
    var minuteAngle: Angle { .degrees(Double(minute) * 6) }
    var hourAngle: Angle {
        let base = Double(hour % 12) * 30.0
        let quarter = Double(minute / 2)
        return .degrees(base + quarter)
    }
    var ampm: String { hour < 12 ? "AM" : "PM" }
    var displayHour: Int { let h = hour % 12; return h == 0 ? 12 : h }
    
    var bgImageName: String { hour < 12 ? "bgDay" : "bgNight" }
    
    var body: some View {
        ZStack {
            Image(bgImageName)
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .overlay(Color.black.opacity(0.25).ignoresSafeArea())
            
            VStack(spacing: 16) {
                Text(String(format: "%02d:%02d %@", displayHour, minute, ampm))
                    .font(.title)
                    .bold()
                    .foregroundColor(.white)
                    .shadow(radius: 6)
                
                ZStack {
                    Circle()
                        .fill(hour < 12 ? Color.green.opacity(0.85) : Color.blue.opacity(0.85))
                        .frame(width: 300, height: 300)
                        .overlay(
                            Circle().stroke(.white.opacity(0.9), lineWidth: 6)
                        )
                        .shadow(radius: 10)
                    
                    Rectangle()
                        .frame(width: 6, height: 120)
                        .foregroundColor(.black)
                        .offset(y: -60)
                        .rotationEffect(minuteAngle)
                    
                    Rectangle()
                        .frame(width: 10, height: 90)
                        .foregroundColor(.black)
                        .offset(y: -45)
                        .rotationEffect(hourAngle)
                    
                    Circle()
                        .frame(width: 16, height: 16)
                        .foregroundColor(.black)
                        .shadow(radius: 3)
                }
                
                VStack(spacing: 10) {
                    HStack(spacing: 12) {
                        Button("- Hour") {
                            hour = (hour == 0) ? 23 : hour - 1
                        }
                        
                        Button("+ Hour") {
                            hour = (hour + 1) % 24
                        }
                    }
                    
                    HStack(spacing: 12) {
                        Button("- Minute") {
                            if minute == 0 {
                                minute = 59
                                hour = (hour == 0) ? 23 : hour - 1
                            } else {
                                minute -= 1
                            }
                        }                        
                        Button("+ Minute") {
                            if minute == 59 {
                                minute = 0
                                hour = (hour + 1) % 24
                            } else {
                                minute += 1
                            }
                        }
                    }
                }
            }
        }        
}
}
